"""Agent 的"怎么读回复"：六个谓词。模板不在这里（在 `prompt.py`）。

收发全是字符串、不收 `Turn`，零包内 import。协议形状是我们自己定的（任务书只规定了沙盒能
跑什么）⇒ 严格只认嵌套形状：prompt 教什么、这里就只认什么；其他形状靠 `looks_like_tool`
判宽接住、落重问（丢一回合、不碰红线）。**不认识任何参数名** —— 参数名是 LLM 写的标签、
由 `Agent.tool_calls` 对注册表认。三条裸块通道（`<summary>` / `<prices>` / `<sop>`）不在此
列：它们不是工具调用，各由一个 best-effort 的解析函数收。
"""

import re

# ── 标签的语法 ────────────────────────────────────────────────────────
#: 所有 `<>` 的解析都在下面这几个正则里；`DOTALL` 一律要（正文里的换行原样保留）。
#: 成对才作数（半截绝不能当内容用）；非贪婪 ⇒ `summary_of` / `is_prices_reply` 只看第一对。
#: 开标签按 `>` 定位（多敲一个空格、加个属性不该让整条回复作废）；`\b` 挡住
#: `<tool_name>`／`<tool_param>` 被当成工具块的开头。
_TOOL_RE = re.compile(r"<tool\b[^>]*>(.*?)</tool>", re.DOTALL)
_NAME_RE = re.compile(r"<tool_name\b[^>]*>(.*?)</tool_name>", re.DOTALL)
#: 嵌套形状：参数写在 `<tool_param>` 里再包一层的具名标签。闭标签用反向引用 `\1` 认同名
#: 那对；`\w+` 是 Unicode 感知的 ⇒ 中文参数名一样认。
_PARAM_RE = re.compile(r"<tool_param\b[^>]*>(.*?)</tool_param>", re.DOTALL)
_INNER_RE = re.compile(r"<(\w+)\b[^>]*>(.*?)</\1>", re.DOTALL)
#: 执行摘要：`<summary>` 块。成对才作数，`summary_of` 只取第一对。
_SUMMARY_RE = re.compile(r"<summary\b[^>]*>(.*?)</summary>", re.DOTALL)
#: `looks_like_tool` 的宽判据（见那里）。与上面几个相反，它故意只认前缀。
_TOOL_MARK_RE = re.compile(r"<tool")
#: 沉淀回复：`<sop>` 块（块里 `<name>` 给名字、其余全是正文）。第 144 步起沉淀不再是
#: 工具调用 —— 与 `<summary>` / `<prices>` 同族的裸块通道（长物料下模型就不会照工具格式
#: 调用，这是那一步的起因）。块里 `<name>` 的标签名与工具参数名同名，但两者不相干。
_SOP_RE = re.compile(r"<sop\b[^>]*>(.*?)</sop>", re.DOTALL)
_SOP_NAME_RE = re.compile(r"<name\b[^>]*>(.*?)</name>", re.DOTALL)
#: 裸 `<prices>` 回复（新闻查价的产物）—— 判别与 `<summary>` 同族。行格式
#: `矿种 方向 [起始天 [天数]]`，两个数字缺省 1（旧的 `矿种 方向` 两词形式照旧合法）。
_PRICES_RE = re.compile(r"<prices\b[^>]*>(.*?)</prices>", re.DOTALL)
_PRICE_LINE_RE = re.compile(
    r"(stone|iron|copper)\s*[：:\s]\s*(up|down|flat|stop)"
    r"(?:\s*[：:\s]\s*(\d+))?(?:\s*[：:\s]\s*(\d+))?",
    re.IGNORECASE,
)
#: 反转义表：prompt 教了 LLM 转义 ⇒ 参数值里的五个预定义实体要还原。`&amp;` 必须最后换
#: （`&amp;lt;` 只该还原一层）。LLM 没转义时这条是空操作 —— 裸 `<` / `>` / `&` 一个都不许改写。
_ENTITIES = (
    ("&lt;", "<"),
    ("&gt;", ">"),
    ("&apos;", "'"),
    ("&quot;", '"'),
    ("&amp;", "&"),
)


def tool_of(reply: str) -> list[tuple[str, list[tuple[str, str]]]] | None:
    """解析这条回复里的工具调用 ⇒ `[(工具名, [(参数名, 原文), …]), …]`（按出现顺序）。

    严格只认嵌套形状，且**整条回复全有或全无**：一个块都没有 ⇒ `None`；任何一个块取不出
    `<tool_name>`、或某块 `<tool_param>` 里一个具名元素都没有（属性式、裸值都不认）⇒ 整次
    `None` —— 半条调用比没有更坏，不猜也不静默丢。只有参数没名字由 `_params` 一并挡掉；
    只有名字没有参数是合法形状（放行与否由 `Agent.tool_calls` 按参数声明判）。
    参数可拆进多个块（块数不是判据），值只去首尾空白、再过 `_unescape`。"""
    calls: list[tuple[str, list[tuple[str, str]]]] = []
    for match in _TOOL_RE.finditer(reply):
        body = match.group(1)
        name = _NAME_RE.search(body)
        params = _params(body)
        if name is None or params is None:
            return None
        calls.append((name.group(1).strip(), params))
    return calls or None


def _params(body: str) -> list[tuple[str, str]] | None:
    r"""收集全部 `<tool_param>` 块里的具名元素 ⇒ `[(参数名, 原文), …]`；任何一块里一个
    具名元素都没有 ⇒ `None`（整次调用不成立）。元素名取标签名（`\w+`，中文也认），值只去
    首尾空白（多行命令、带缩进的 python 都合法）。参数可拆进多个块（块数不是判据）。"""
    params: list[tuple[str, str]] = []
    for match in _PARAM_RE.finditer(body):
        inner = _INNER_RE.findall(match.group(1))
        if not inner:
            return None
        params += [(tag, _unescape(value.strip())) for tag, value in inner]
    return params


def _unescape(text: str) -> str:
    """把五个 XML 预定义实体还原成原字符（`&amp;` 最后换，见 `_ENTITIES` 的注释）。"""
    for entity, char in _ENTITIES:
        text = text.replace(entity, char)
    return text


def summary_of(reply: str) -> str:
    """每条回复搭车的执行摘要 ⇒ 第一对 `<summary>` 块的内容；取不到 ⇒ `""`。

    best-effort：取不到（没写 / 半截 / 空块）⇒ 保旧摘要继续，绝不重问（摘要是搭车品、
    重问要花一回合）。不回落原文：拿半截标记去凑只会把标签串当内容用。"""
    block = _SUMMARY_RE.search(reply)
    return block.group(1).strip() if block else ""


def is_summary_reply(reply: str) -> str | None:
    """裸摘要回复（压缩轮的产物）⇒ 返回摘要文本；否则 `None`。

    判据：`<summary>` 块取得出内容，且挖掉摘要块之后一个字不剩 —— 任务回复（带工具调用 /
    正文）不算。任务 prompt 不教摘要 ⇒ "裸摘要"几乎必属压缩回复；粘住同文再判仍幂等。"""
    summary = summary_of(reply)
    if summary and not _SUMMARY_RE.sub("", reply).strip():
        return summary
    return None


def sops_of(reply: str) -> list[tuple[str, str]]:
    """沉淀回复里的条目 ⇒ `[(名字, 正文), …]`（按出现顺序）；一条都没有 ⇒ `[]`。

    best-effort，与 `summary_of` / `is_prices_reply` 同族：块可以夹在散文里（长物料下模型
    常常先解释两句再给块），只取块本身。块内 `<name>` 与正文**都要有**才作数 —— 缺一个就
    丢那一条（不猜、也不回落原文：半截标记当内容用只会存进一条垃圾）。
    正文 = 块里挖掉 `<name>` 之后剩下的部分，只去首尾空白、**不反转义**（它是给人读的四栏
    散文，不是命令参数；顺带也不怕模型把正文里的 `<` 写成了实体）。"""
    entries: list[tuple[str, str]] = []
    for block in _SOP_RE.finditer(reply):
        body = block.group(1)
        name = _SOP_NAME_RE.search(body)
        text = _SOP_NAME_RE.sub("", body).strip()
        if name is not None and name.group(1).strip() and text:
            entries.append((name.group(1).strip(), text))
    return entries


def is_prices_reply(reply: str) -> list[tuple[str, str, int, int]] | None:
    """裸 `<prices>` 回复（新闻查价的产物）⇒ `[(矿种, 方向, 起始天, 天数), …]`（按出现顺序）；
    否则 `None`。判据与 `is_summary_reply` 同构，行格式见 `_PRICE_LINE_RE`。

    数字缺省 1（起始天 1 = 明天）。同一种矿可以出现两行（`iron up 1 2` 与 `iron stop 1 2` ——
    又涨价又停工正是任务书那段塌方的样子）⇒ 返回的是**列表**而不是按矿种去重的字典。"""
    block = _PRICES_RE.search(reply)
    if block is None or _PRICES_RE.sub("", reply).strip():
        return None
    return [
        (m.group(1).lower(), m.group(2).lower(), int(m.group(3) or 1), int(m.group(4) or 1))
        for m in _PRICE_LINE_RE.finditer(block.group(1))
    ]


def looks_like_tool(reply: str) -> bool:
    """这条回复像工具调用吗？只认开标签前缀出现（故意判宽）。

    只有 `<tool_name>` 的回复、解析不出的形状都该被认成"它想调工具、但格式没凑对" ⇒
    落重问（`Agent.reject_shape` 把原因回灌进会话），而不是被当成一段普通文本打发掉。
    本模块唯一只认前缀的地方 —— 别顺手改成 `_TOOL_RE`：那会把"想调但没凑对"漏过去。"""
    return _TOOL_MARK_RE.search(reply) is not None
